import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'models/Assignment.dart';
import 'dart:convert';
import 'models/Subject.dart';
import 'styles.dart';
import 'screens/secondaryDashboard.dart';
import 'models/Module.dart' as mod;
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  static const String _title = 'Flutter Code Sample';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        cardColor: Color(0xFF101010),
      ),
      title: _title,
      home: MyStatelessWidget(),
    );
  }
}

class MyStatelessWidget extends StatefulWidget {
  MyStatelessWidget({Key key}) : super(key: key);

  @override
  _MyStatelessWidgetState createState() => _MyStatelessWidgetState();
}

class _MyStatelessWidgetState extends State<MyStatelessWidget>
    with TickerProviderStateMixin {
  final String urlAssignment =
      'https://dribbler.pythonanywhere.com/v1/assignment/';
  final String urlSubject = 'https://dribbler.pythonanywhere.com/v1/subject/';
  final String urlModule = 'https://dribbler.pythonanywhere.com/v1/module/';

  Assignment assignment;
  mod.Module module;
  SubjectEach newSubject;

  // Animation
  AnimationController _controller;
  Animation _animation;

  Future<String> fetchDataAssignment() async {
    var response = await http.get(urlAssignment);
    var jsonDecoded = jsonDecode(response.body);
    assignment = Assignment.fromJson(jsonDecoded);
    setState(() {});
    return "Success";
  }

  Future<String> fetchDataSubject() async {
    var response = await http.get(urlSubject);
    var jsonDecoded = jsonDecode(response.body);
    newSubject = SubjectEach.fromJson(jsonDecoded);
    setState(() {});
    return "Success";
  }

  Future<String> fetchDataModule() async {
    var response = await http.get(urlModule);
    //print(response.body);
    var jsonDecoded = jsonDecode(response.body);
    module = mod.Module.fromJson(jsonDecoded);
    setState(() {});
    return "Success";
  }

  // TODO: Persistence of last response got from api
  // package: pref_dessert

  void animationCard() {
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    fetchDataSubject();
    fetchDataAssignment();
    fetchDataModule();

    _controller = new AnimationController(
      duration: new Duration(milliseconds: 1000),
      vsync: this,
    )..addListener(() {
        this.setState(() {});
      });

    Tween _tween = new Tween<double>(begin: 0, end: 1);
    _controller.forward();

    _animation = _tween.animate(_controller);
    _controller.forward();

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: new Icon(FontAwesomeIcons.dashcube),
        title: Text(
          'Dribbler',
        ),
        actions: <Widget>[],
      ),
      backgroundColor: Colors.black,
      body: newSubject == null
          ? Center(
              child: SpinKitFadingCube(
                size: 40,
                itemBuilder: (context, int index) {
                  return DecoratedBox(
                      decoration: BoxDecoration(
                    color: index.isEven ? Colors.white : Colors.grey,
                  ));
                },
              ),
            )
          : ListView(
              children: newSubject.results.map((eachResult) {
                return Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 4.0, vertical: 2.0),
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (BuildContext context, Widget child) => child,
                    child: Transform.scale(
                      scale: _animation.value,
                      child: Container(
                          height: 100,
                          child: InkWell(
                            onTap: () {
                              // Pass the subject name and all its related items
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => DashboardModule(
                                            id: eachResult.id,
                                            title: eachResult.name,
                                            assignment: assignment,
                                            module: module,
                                          )));
                            },
                            child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(0.0)),
                              child: Card(
                                clipBehavior: Clip.antiAlias,
                                  elevation: 0.0,
                                  child: Center(
                                      child: new Text(
                                    eachResult.name,
                                    style: cardTitle,
                                  ))),
                            ),
                          )),
                    ),
                  ),
                );
              }).toList(),
            ),
      bottomSheet: new Container(
        height: 20,
        alignment: Alignment.bottomCenter,
        color: Colors.black,
        child: new Text(
          "Version 1.0.0",
          style: TextStyle(fontSize: 10),
        ),
      ),
    );
  }
}
