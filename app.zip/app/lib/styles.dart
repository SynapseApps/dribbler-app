import 'package:flutter/material.dart';


const TextStyle cardTitle = TextStyle(fontSize: 20);
const TextStyle assignmentCard = TextStyle(fontSize: 15.0, fontWeight: FontWeight.bold);