void fetch(){
  print("This is a fetch function");
}